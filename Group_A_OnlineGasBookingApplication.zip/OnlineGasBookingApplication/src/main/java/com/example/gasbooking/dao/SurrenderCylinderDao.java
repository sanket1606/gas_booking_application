package com.example.gasbooking.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gasbooking.entity.SurrenderCylinder;


public interface SurrenderCylinderDao extends JpaRepository<SurrenderCylinder, Integer> {

}
