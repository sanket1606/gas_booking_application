package com.example.gasbooking.exception;

public class AdminNotFoundException {
	private static final long serialVersionUID = -5595964428948080655L;

}
