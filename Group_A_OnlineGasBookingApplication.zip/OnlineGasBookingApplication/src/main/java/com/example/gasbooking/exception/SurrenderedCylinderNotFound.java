package com.example.gasbooking.exception;



public class SurrenderedCylinderNotFound extends RuntimeException {

	public SurrenderedCylinderNotFound(String message) {
		super(message);
	}
}

