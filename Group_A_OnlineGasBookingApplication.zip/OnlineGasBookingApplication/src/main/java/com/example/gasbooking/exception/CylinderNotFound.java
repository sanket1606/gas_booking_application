package com.example.gasbooking.exception;

public class CylinderNotFound extends RuntimeException {

	public CylinderNotFound(String message) {
		super(message);
	}
}
