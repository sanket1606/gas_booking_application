package com.example.gasbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineGasBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
